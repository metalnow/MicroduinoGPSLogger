MicroduinoGPSLogger
===================

GPS Logger with sdcard module implementation

Hardware setup Ref: http://www.microduino.cc/Forum%20Application/13-build-microduino-gpsloggerspeedmetor

1. Microduino-Core+ : (MCU of this system)

2. Microduino-FT232R : upload program from PC to -Core+

3. Microduino-NEO6M : GPS module

4. Microduino-SD: to record logger information to a microSD card

5. Microduino-OLED: display 

6. holes board or Microduino general purpose application board: Microduino-Cube-V1

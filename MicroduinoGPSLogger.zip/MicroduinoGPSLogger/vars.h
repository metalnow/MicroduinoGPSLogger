static uint8_t uiKeyCode;
char line1[17];
char line2[17];
static uint8_t refreshLCD;
